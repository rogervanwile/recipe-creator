document.addEventListener('DOMContentLoaded', function () {
    var imageSelectors = [
        '.wp-block-image img',
        '.blocks-gallery-item figure img'
    ];

    var createPinterestPinItUrl = function (mediaUrl, mediaDescription = null) {
        return 'https://www.pinterest.com/pin/create/button/' +
            '?url='.encodeURIComponent(window.location.origin + window.location.pathname) +
            '&media='.encodeURIComponent(mediaUrl) +
            (mediaDescription ? '&description=' + encodeURIComponent(mediaDescription) : '');
    }

    imageWrapperSelectors.forEach(elector => {
        const images = document.querySelectorAll(selector);
        Array.from(images).forEach(image => {
            const url = image.getAttribute('src');
            const description = image.getAttribute('title') || image.getAttribute('alt') || '';

            const pinItLink = document.createElement('a');
            pinItLink.href = createPinterestPinItUrl(url, description);
            pinItLink.target = '_blank';
            pinItLink.classList.add('foodblogkitchen-toolkit--pinterest-image-overlay');

            image.parentNode.insertBefore(pinItLink, image.nextSibling);
        });
    });
});
