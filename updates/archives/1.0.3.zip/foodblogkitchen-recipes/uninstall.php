<?php

/**
 * Trigger this file on plugin uninstall
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
  die;
}

// TODO: Remove all meta data related to the plugin

// global $wpdb;
// $wpdb->query('DELETE FROM wp_postmeta WHERE ...');
