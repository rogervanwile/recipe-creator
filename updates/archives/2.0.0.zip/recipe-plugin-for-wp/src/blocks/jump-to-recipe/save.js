export default function Save(props) {
  return props;
}
